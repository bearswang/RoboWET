function [N, M, h_m_1, g_m_1, h_m_2, g_m_2] = channel( N, M, monte )
% channel regs
h_m_nlos=zeros(N,1,2,M,monte);
g_m_nlos=zeros(N,1,2,M,monte);

PL=zeros(2,M,1); % pathloss
rho=1e-3; % pathloss for 1 meter

for mon =1:monte
    % distance dependent pathloss
    d=zeros(2,M);
    d(1,1)=4;
    d(2,1)=4;
    d(1,2)=1;
    d(2,2)=7;
    d(1,3)=7;
    d(2,3)=1;
    d(1,4)=4;
    d(2,4)=4;

    for m=1:M
        for i=1:2
            PL(i,m)=rho*(d(i,m)^-2.7); % pathloss
        end
    end
    % combine pathloss with fastfading
    for m=1:M
        for i=1:2
            h_m_nlos(:,:,i,m,mon)=sqrt(PL(i,m))*sqrt(0.5)*(randn(N,1)+sqrt(-1)*randn(N,1));
            g_m_nlos(:,:,i,m,mon)=sqrt(PL(i,m))*sqrt(0.5)*(randn(N,1)+sqrt(-1)*randn(N,1));
        end
    end 
end

h_m_1=h_m_nlos;
g_m_1=g_m_nlos;

for mon =1:monte
    % distance dependent pathloss
    d=zeros(2,M); % 1 to 10 meters

    d(1,2)=5;
    d(2,2)=5;
    d(1,3)=5;
    d(2,3)=5;

    for m=2:M-1
        for i=1:2
            PL(i,m)=rho*(d(i,m)^-2.7); % pathloss
        end
    end
    % combine pathloss with fastfading
    for m=2:M-1
        for i=1:2
            h_m_nlos(:,:,i,m,mon)=sqrt(PL(i,m))*sqrt(0.5)*(randn(N,1)+sqrt(-1)*randn(N,1));
            g_m_nlos(:,:,i,m,mon)=sqrt(PL(i,m))*sqrt(0.5)*(randn(N,1)+sqrt(-1)*randn(N,1));
        end
    end
      
end

h_m_2=h_m_nlos;
g_m_2=g_m_nlos;


end

