% Generate channels
clear all;
N = 8; % the number of antennas at relay
M = 4; % the number of stopping points
monte =100;

[N M h_m_1 g_m_1 h_m_2 g_m_2] = channel(N, M, monte); % Rayleigh fading channel
% [N K h_m g_m] = channel_rician(N, K, monte); % Rician fading channel
save('channel.mat');